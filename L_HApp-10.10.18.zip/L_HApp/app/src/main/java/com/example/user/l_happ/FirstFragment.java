package com.example.user.l_happ;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class FirstFragment extends Fragment{
    EditText lhid,name,dob,fname,mname;
    RadioGroup food;
  RadioButton radioButton;
  FloatingActionButton tick;
    public FirstFragment(){

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.fragment_first, container, false);

        lhid = (EditText) view.findViewById(R.id.lhid);
        name = (EditText) view.findViewById(R.id.name);
        dob = (EditText) view.findViewById(R.id.dob);
        fname = (EditText) view.findViewById(R.id.fname);
        mname = (EditText) view.findViewById(R.id.mname);
        food = (RadioGroup) view.findViewById(R.id.radioGroup);
        tick=(FloatingActionButton)view.findViewById(R.id.done);
        tick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.lh_id = lhid.getText().toString();
                MainActivity.name = name.getText().toString();
                MainActivity.dob = dob.getText().toString();
                MainActivity.fname = fname.getText().toString();
                MainActivity.mname = mname.getText().toString();
                int id = food.getCheckedRadioButtonId();
                radioButton = (RadioButton) view.findViewById(id);
                MainActivity.food = radioButton.getText().toString();
            }
        });






        /*name = (EditText)view.findViewById(R.id.name);
        dob = (EditText)view.findViewById(R.id.dob);
        fname = (EditText)view.findViewById(R.id.fname);
        mname = (EditText)view.findViewById(R.id.mname);
        food = (RadioGroup)view.findViewById(R.id.radioGroup);

          next= (Button)view.findViewById(R.id.next);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /////////////////////////*if(view.getId()==R.id.next);
                    /////////////////////////mcallback.passData(lhid.getText().toString());

*/
        //Bundle b = new Bundle();
        //b.putString("lhid", "hello");
                /*b.putString("name", name.getText().toString());lhid.getText().toString()
                b.putString("dob", dob.getText().toString());
                b.putString("fname", fname.getText().toString());
                b.putString("mname", mname.getText().toString());
                int id = food.getCheckedRadioButtonId();
                RadioButton radioButton = (RadioButton)view.findViewById(id);
                b.putString("food", radioButton.getText().toString());*/

                /*ThirdFragment t3 = new ThirdFragment();
                t3.setArguments(b);
                getFragmentManager().beginTransaction().add(R.id.frameLayout, t3).commit();*/

                    /*Fragment f=new SecondFragment();
                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.frameLayout, f);
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
                ft.commit();
            }
        });*/
       /* ThirdFragment t3 = new ThirdFragment();
        t3.setArguments(b);*/
        return view;
    }
   /* @Override
    public void onScrollChange(View view, int i, int i1, int i2, int i3) {
        MainActivity.lh_id=lhid.getText().toString();
        MainActivity.name=name.getText().toString();
        MainActivity.dob=dob.getText().toString();
        MainActivity.fname=fname.getText().toString();
        MainActivity.mname=mname.getText().toString();
        MainActivity.food=radioButton.getText().toString();
    }*/

    /*public class Fragment1 extends AppCompatActivity {


        Intent intent = new Intent(getApplicationContext(), ThirdFragment.class);

        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.fragment_first);


            FrameLayout f = (FrameLayout) findViewById(R.id.frameLayout);
            MainActivity ma=new MainActivity();
            ma.tb.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

                @Override
                public void onTabSelected(TabLayout.Tab tab) {

                    Fragment f = null;
                    switch (tab.getPosition()) {
                        case 0:
                            f = new FirstFragment();
                            break;
                        case 1:
                            f = new SecondFragment();
                            break;
                        case 2:
                            f = new ThirdFragment();
                            break;
                    }
                    Bundle b = new Bundle();
                    b.putString("lhid", lhid.getText().toString());
                    b.putString("name", name.getText().toString());
                    b.putString("dob", dob.getText().toString());
                    b.putString("fname", fname.getText().toString());
                    b.putString("mname", mname.getText().toString());
                    int id = food.getCheckedRadioButtonId();
                    RadioButton radioButton = (RadioButton) findViewById(id);
                    b.putString("food", radioButton.getText().toString());
                    intent.putExtras(b);

                    FragmentManager fm = getSupportFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.frameLayout, f);
                    ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
                    ft.commit();
                }
                @Override
                public void onTabUnselected(TabLayout.Tab tab) {

                }

                @Override
                public void onTabReselected(TabLayout.Tab tab) {

                }
            });



        }
    }*/
}
