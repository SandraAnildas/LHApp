package com.example.user.l_happ;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class Login extends AppCompatActivity {
    EditText username, password;
    Button login;
    String uname,pswd,us,pa;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username=(EditText)findViewById(R.id.username);
        password=(EditText)findViewById(R.id.password);
        login=(Button)findViewById(R.id.IN);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uname= username.getText().toString();
                pswd= password.getText().toString();
                getJSON("https://sanvika6215.000webhostapp.com/getphp.php");

            }
        });
    }
    void check(){
            if(uname.equals(us) && pswd.equals(pa)){
                Toast.makeText(Login.this, "Login success", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(Login.this, "Login failure: "+uname+ "..."+us, Toast.LENGTH_LONG).show();
        }
    }
    private void getJSON(final String urlWebService) {

        class GetJSON extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected void onPostExecute(String s) {
               super.onPostExecute(s);
               try {
                   retrieveData(s);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(urlWebService);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return "hello"+e;
                }

            }
        }
        GetJSON getJSON = new GetJSON();
        getJSON.execute();
    }

   private void retrieveData(String json) throws JSONException {
       JSONObject obj = new JSONObject(json);
       JSONObject sys=obj.getJSONObject("0");
       us=sys.getString("id");
       pa=sys.getString("name");
       check();
    }
}
