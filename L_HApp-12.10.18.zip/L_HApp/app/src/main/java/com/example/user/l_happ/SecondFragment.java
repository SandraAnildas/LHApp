package com.example.user.l_happ;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class SecondFragment extends Fragment {
    FloatingActionButton tick;
    EditText address,contact,fnum,mnum;
    public SecondFragment(){

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_second,container,false);
        address = (EditText)view.findViewById(R.id.address);
        contact = (EditText)view.findViewById(R.id.contact);
        fnum = (EditText)view.findViewById(R.id.fnum);
        mnum = (EditText)view.findViewById(R.id.mnum);
        tick=(FloatingActionButton)view.findViewById(R.id.done);
        tick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.address=address.getText().toString();
                MainActivity.contact=contact.getText().toString();
                MainActivity.fnum=fnum.getText().toString();
                MainActivity.mnum=mnum.getText().toString();
            }
        });
        return view;
    }
}
