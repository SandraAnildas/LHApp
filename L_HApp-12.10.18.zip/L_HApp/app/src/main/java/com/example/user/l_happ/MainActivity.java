package com.example.user.l_happ;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.TabItem;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{
    TabLayout tb;
    FrameLayout f;
    static String lh_id,name,dob,fname,mname,food,address,contact,fnum,mnum;
    //TabLayout.Tab t1,t2,t3;
    ViewPager viewpager;
    Fragment ff;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        f=(FrameLayout)findViewById(R.id.frameLayout);
        tb = (TabLayout) findViewById(R.id.tablayout);
        viewpager = (ViewPager) findViewById(R.id.View);

        tb.addTab(tb.newTab().setText("Personal").setIcon(R.drawable.personalinfo));
        tb.addTab(tb.newTab().setText("Contact").setIcon(R.drawable.call));
        tb.addTab(tb.newTab().setText("Academics").setIcon(R.drawable.graduation_cap));
        PagerAdapter adapter = new PageAdapter(getSupportFragmentManager(), tb.getTabCount());
        viewpager.setAdapter(adapter);
        viewpager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tb));
        tb.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                switch (tab.getPosition()) {
                    case 0:
                        ff=new FirstFragment();
                        break;
                    case 1:
                        ff = new SecondFragment();
                        break;
                    case 2:
                        ff = new ThirdFragment();

                        break;
                }
                FragmentManager fm = getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.frameLayout, ff);
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
                ft.commit();
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }
}
