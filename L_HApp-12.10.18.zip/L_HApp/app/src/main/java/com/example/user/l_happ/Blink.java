package com.example.user.l_happ;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class Blink extends AppCompatActivity {
    Animation blink;
    ImageView img;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blink_main);
        startBlinkingApplication(null);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run(){
                intent = new Intent(Blink.this, Login.class);
                startActivity(intent);
            }
        },5000);

    }
    public void startBlinkingApplication(View view) {
        img = (ImageView) findViewById(R.id.img);
        blink = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.blink_anim);
        img.startAnimation(blink);


    }
}
